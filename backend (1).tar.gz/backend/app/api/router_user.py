from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from app.schemas.user import UserCreate, UserOut, UserUpdate
from app.api.deps import get_db
from app.services import user_service

router = APIRouter()

# --- CREATE ---
@router.post("/users", response_model=UserOut)
def create_user_route(data: UserCreate, db: Session = Depends(get_db)):
    result = user_service.create_user(data, db)
    
    if result == "exists":
        raise HTTPException(status_code=400, detail="Email already registered")
    if result == "role_error":
        raise HTTPException(status_code=400, detail="Role does not exist")
    if result is None:
        raise HTTPException(status_code=400, detail="Invalid email address or DNS lookup failed")
        
    return UserOut(id=result.id, email=result.email, role=result.role.name)

# --- READ LIST ---
@router.get("/users", response_model=List[UserOut])
def list_users(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    users = user_service.get_all_users(db, skip, limit)
    # Mapeo manual o usar ORM mode de Pydantic
    return [UserOut(id=u.id, email=u.email, role=u.role.name) for u in users]

# --- READ ONE ---
@router.get("/users/{user_id}", response_model=UserOut)
def get_user(user_id: int, db: Session = Depends(get_db)):
    user = user_service.get_user_by_id(user_id, db)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return UserOut(id=user.id, email=user.email, role=user.role.name)

# --- UPDATE ---
@router.put("/users/{user_id}", response_model=UserOut)
def update_user_route(user_id: int, data: UserUpdate, db: Session = Depends(get_db)):
    result = user_service.update_user(user_id, data, db)
    
    if result is None:
        raise HTTPException(status_code=404, detail="User not found")
    if result == "invalid_email":
        raise HTTPException(status_code=400, detail="New email is not valid/real")
    if result == "email_exists":
        raise HTTPException(status_code=400, detail="New email is already in use")
    if result == "role_error":
        raise HTTPException(status_code=400, detail="Role does not exist")
        
    return UserOut(id=result.id, email=result.email, role=result.role.name)

# --- DELETE ---
@router.delete("/users/{user_id}")
def delete_user_route(user_id: int, db: Session = Depends(get_db)):
    success = user_service.delete_user(user_id, db)
    if not success:
        raise HTTPException(status_code=404, detail="User not found")
    return {"message": "User deleted successfully"}