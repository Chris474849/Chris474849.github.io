from sqlalchemy.orm import Session
from validate_email import validate_email
from app.core.security import hash_password
from app.models.user import User
from app.models.role import Role
from app.models.password import Password

def create_default_roles(db: Session):
    roles = ["admin", "worker", "client"]
    for r in roles:
        exists = db.query(Role).filter(Role.name == r).first()
        if not exists:
            db.add(Role(name=r))
    db.commit()
    
# --- VALIDACIÓN DE EMAIL ---
def check_email_is_real(email: str) -> bool:
    # check_dns=True verifica que el dominio tenga servidores de correo (MX records)
    # check_smtp=True intentaría conectar al servidor (es más lento y a veces bloqueado)
    # Usamos check_dns=True como balance de velocidad/realidad.
    return validate_email(email, check_format=True, check_dns=True)

# --- CRUD CREATE ---
def create_user(data, db: Session):
    # 1. Validar que el email sea real
    if not check_email_is_real(data.email):
        return None # O lanzar excepción personalizada
    
    # 2. Verificar si ya existe en la BD
    exists = db.query(User).filter(User.email == data.email).first()
    if exists:
        return "exists" # Retorno especial para indicar duplicado

    # 3. Verificar Rol
    role = db.query(Role).filter(Role.name == data.role).first()
    if not role:
        return "role_error"

    # 4. Crear Usuario
    user = User(email=data.email, role_id=role.id)
    db.add(user)
    db.commit()
    db.refresh(user)

    # 5. Crear Password (si aplica)
    if data.password:
        pwd_hash = hash_password(data.password)
        pwd = Password(hash=pwd_hash, user_id=user.id)
        db.add(pwd)
        db.commit()
    
    return user

# --- CRUD READ ---
def get_user_by_id(user_id: int, db: Session):
    return db.query(User).filter(User.id == user_id).first()

def get_all_users(db: Session, skip: int = 0, limit: int = 100):
    return db.query(User).offset(skip).limit(limit).all()

# --- CRUD UPDATE ---
def update_user(user_id: int, data, db: Session):
    user = get_user_by_id(user_id, db)
    if not user:
        return None

    # Si se actualiza el email, verificar validez y duplicados
    if data.email and data.email != user.email:
        if not check_email_is_real(data.email):
            return "invalid_email"
        exists = db.query(User).filter(User.email == data.email).first()
        if exists:
            return "email_exists"
        user.email = data.email

    # Si se actualiza el rol
    if data.role:
        role = db.query(Role).filter(Role.name == data.role).first()
        if not role:
            return "role_error"
        user.role_id = role.id

    # Si se actualiza la contraseña
    if data.password:
        new_hash = hash_password(data.password)
        if user.password:
            user.password.hash = new_hash # Actualizar existente
        else:
            # Crear nueva entrada si no tenía
            pwd = Password(hash=new_hash, user_id=user.id)
            db.add(pwd)
    
    db.commit()
    db.refresh(user)
    return user

# --- CRUD DELETE ---
def delete_user(user_id: int, db: Session):
    user = get_user_by_id(user_id, db)
    if not user:
        return False
    
    # Opcional: Borrar password y tokens asociados manualmente si no hay CASCADE en BD
    if user.password:
        db.delete(user.password)
        
    db.delete(user)
    db.commit()
    return True