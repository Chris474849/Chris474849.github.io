<script setup>
import NavBar from './components/NavBar.vue'
import HeroSection from './components/HeroSection.vue'
import ServicesSection from './components/ServicesSection.vue'
import PortfolioSection from './components/PortfolioSection.vue'
import AboutSection from './components/AboutSection.vue'
import ContactSection from './components/ContactSection.vue'
import FooterSection from './components/FooterSection.vue'
</script>

<template>
  <div>
    <NavBar />
    <HeroSection />
    <ServicesSection />
    <PortfolioSection />
    <AboutSection />
    <ContactSection />
    <FooterSection />
  </div>
</template>

<style>
:root {
  --primary-color: #2c3e50;
  --secondary-color: #e67e22;
  --light-color: #ecf0f1;
  --dark-color: #1a252f;
}

* {
  box-sizing: border-box;
}

html {
  scroll-behavior: smooth;
}

body {
  font-family: 'Montserrat', sans-serif;
  color: var(--primary-color);
  background-color: var(--light-color);
  margin: 0;
  padding: 0;
  overflow-x: hidden;
}

/* Mejoras para dispositivos muy pequeños */
@media (max-width: 576px) {
  .container {
    padding-left: 10px !important;
    padding-right: 10px !important;
  }
  
  /* Reducir padding general en secciones */
  section {
    padding: 30px 0 !important;
  }
  
  /* Tamaños de texto optimizados */
  h1 {
    font-size: 1.8rem !important;
    line-height: 1.2 !important;
  }
  
  h2 {
    font-size: 1.5rem !important;
    line-height: 1.3 !important;
  }
  
  h3 {
    font-size: 1.3rem !important;
  }
  
  p, .lead {
    font-size: 0.9rem !important;
    line-height: 1.5 !important;
  }
  
  /* Botones más pequeños en mobile */
  .btn {
    padding: 8px 16px !important;
    font-size: 0.9rem !important;
  }
  
  .btn-lg {
    padding: 10px 20px !important;
    font-size: 1rem !important;
  }
}

@media (max-width: 400px) {
  .container {
    padding-left: 8px !important;
    padding-right: 8px !important;
  }
  
  section {
    padding: 25px 0 !important;
  }
  
  h1 {
    font-size: 1.6rem !important;
  }
  
  h2 {
    font-size: 1.3rem !important;
  }
  
  p, .lead {
    font-size: 0.85rem !important;
  }
  
  .btn {
    padding: 6px 14px !important;
    font-size: 0.85rem !important;
  }
  
  .btn-lg {
    padding: 8px 18px !important;
    font-size: 0.9rem !important;
  }
}

/* Evitar scroll horizontal */
.row {
  margin-left: 0 !important;
  margin-right: 0 !important;
}

.col, .col-*, [class*="col-"] {
  padding-left: 8px !important;
  padding-right: 8px !important;
}

@media (max-width: 576px) {
  .col, .col-*, [class*="col-"] {
    padding-left: 5px !important;
    padding-right: 5px !important;
  }
}
</style>
