from sqlalchemy.orm import Session
# Asegúrate de importar EmailNotValidError
from email_validator import validate_email, EmailNotValidError 
from app.core.security import hash_password
from app.models.user import User
from app.models.role import Role
from app.models.password import Password

def create_default_roles(db: Session):
    roles = ["admin", "worker", "client"]
    for r in roles:
        exists = db.query(Role).filter(Role.name == r).first()
        if not exists:
            db.add(Role(name=r))
    db.commit()
    
# --- (La función check_email_is_real ya no es necesaria como wrapper simple 
#      porque queremos el mensaje de error exacto dentro del flujo, 
#      la integramos directamente abajo) ---

# --- CRUD CREATE ---
def create_user(data, db: Session):
    # 1. Validar email, verificar existencia, verificar rol (Lógica anterior OK)
    try:
        valid = validate_email(data.email, check_deliverability=True)
        email_normalized = valid.normalized
    except EmailNotValidError as e:
        return {"error": "invalid_email", "msg": str(e)}
    
    exists = db.query(User).filter(User.email == email_normalized).first()
    if exists:
        return "exists" 

    role = db.query(Role).filter(Role.name == data.role).first()
    if not role:
        return "role_error"

    # 4. Crear Usuario: Añadir a la sesión
    user = User(email=email_normalized, role_id=role.id)
    db.add(user)
    
    # VITAL: Usamos flush() para obtener el user.id sin hacer COMMIT final
    try:
        db.flush() 
        db.refresh(user) 
    except Exception as e:
        # Si el flush falla por alguna razón (ej. restricción), hacemos rollback
        db.rollback()
        raise e

    # 5. Crear Password
    if data.password:
        try:
            # Prevención: Truncamos la contraseña para evitar el ValueError de 72 bytes
            pwd_hash = hash_password(data.password)

            pwd = Password(hash=pwd_hash, user_id=user.id)
            db.add(pwd)
            
        except Exception:
            # SI EL HASHING FALLA (AttributeError, ValueError, etc.), 
            # revertimos la creación del usuario y re-lanzamos el error.
            db.rollback() 
            raise 

    # 6. COMMIT ÚNICO y ATÓMICO: Si llegamos aquí, el usuario y el password se guardan juntos.
    db.commit() 
    
    return user

# --- CRUD READ ---
def get_user_by_id(user_id: int, db: Session):
    return db.query(User).filter(User.id == user_id).first()

def get_all_users(db: Session, skip: int = 0, limit: int = 100):
    return db.query(User).offset(skip).limit(limit).all()

# --- CRUD UPDATE ---
def update_user(user_id: int, data, db: Session):
    user = get_user_by_id(user_id, db)
    if not user:
        return None

    # Si se actualiza el email
    if data.email and data.email != user.email:
        try:
            valid = validate_email(data.email, check_deliverability=True)
            email_normalized = valid.normalized
        except EmailNotValidError as e:
            return {"error": "invalid_email", "msg": str(e)}

        exists = db.query(User).filter(User.email == email_normalized).first()
        if exists:
            return "email_exists"
        
        user.email = email_normalized

    # Si se actualiza el rol
    if data.role:
        role = db.query(Role).filter(Role.name == data.role).first()
        if not role:
            return "role_error"
        user.role_id = role.id

    # Si se actualiza la contraseña
    if data.password:
        new_hash = hash_password(data.password)
        if user.password:
            user.password.hash = new_hash 
        else:
            pwd = Password(hash=new_hash, user_id=user.id)
            db.add(pwd)
    
    db.commit()
    db.refresh(user)
    return user

# --- CRUD DELETE ---
def delete_user(user_id: int, db: Session):
    user = get_user_by_id(user_id, db)
    if not user:
        return False
    
    if user.password:
        db.delete(user.password)
        
    db.delete(user)
    db.commit()
    return True