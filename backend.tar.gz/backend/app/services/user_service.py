from sqlalchemy.orm import Session
from validate_email import validate_email
from app.core.security import hash_password
from app.models.user import User
from app.models.role import Role
from app.models.password import Password

def create_default_roles(db: Session):
    roles = ["admin", "worker", "client"]
    for r in roles:
        exists = db.query(Role).filter(Role.name == r).first()
        if not exists:
            db.add(Role(name=r))
    db.commit()

def create_user(data, db: Session):
    valid = validate_email(data.email, check_format=True, check_dns=True)
    if not valid:
        return None
    exists = db.query(User).filter(User.email == data.email).first()
    if exists:
        return exists
    role = db.query(Role).filter(Role.name == data.role).first()
    if not role:
        return None
    user = User(email=data.email, role_id=role.id)
    db.add(user)
    db.commit()
    db.refresh(user)
    if data.role in ["admin", "worker"]:
        if not data.password:
            return None
        pwd = Password(hash=hash_password(data.password), user_id=user.id)
        db.add(pwd)
        db.commit()
    return user
