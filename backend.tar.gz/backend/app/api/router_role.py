from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.api.deps import get_db
from app.models.role import Role

router = APIRouter()

@router.get("/roles")
def list_roles(db: Session = Depends(get_db)):
    return db.query(Role).all()

@router.post("/roles")
def create_role(name: str, db: Session = Depends(get_db)):
    r = Role(name=name)
    db.add(r)
    db.commit()
    db.refresh(r)
    return r

@router.delete("/roles/{role_id}")
def delete_role(role_id: int, db: Session = Depends(get_db)):
    r = db.query(Role).filter(Role.id == role_id).first()
    if not r:
        return None
    db.delete(r)
    db.commit()
    return {"ok": True}
