from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.schemas.user import UserCreate, UserOut
from app.api.deps import get_db
from app.services.user_service import create_user

router = APIRouter()

@router.post("/users", response_model=UserOut)
def create_user_route(data: UserCreate, db: Session = Depends(get_db)):
    user = create_user(data, db)
    if not user:
        return {"error": "Cannot create user"}
    return UserOut(id=user.id, email=user.email, role=user.role.name)
